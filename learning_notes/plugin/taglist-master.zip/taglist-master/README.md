taglist - Source Code Browser plugin for Vim
============================================

The "Tag List" plugin is a source code browser plugin for Vim and 
provides an overview of the structure of source code files and allows 
you to efficiently browse through source code files for different 
programming languages.

The github page for the taglist plugin is at:

	http://github.com/yegappan/taglist

You can visit the taglist plugin home page for more information:

      http://vim-taglist.sourceforge.net

For more information about using this plugin, after installing the
taglist plugin, use the ":help taglist" command.
